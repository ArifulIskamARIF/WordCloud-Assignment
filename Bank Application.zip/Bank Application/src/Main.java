import GUI.*;
public class Main {
    public static void main(String[] args) {
        homePage mainPage = new homePage();
        mainPage.setVisible(true);
    }
}