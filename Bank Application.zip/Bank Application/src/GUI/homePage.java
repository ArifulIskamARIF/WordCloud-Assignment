package GUI;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.*;
import javax.imageio.*;
import java.io.File;
import java.io.IOException;



public class homePage extends JFrame {

    // Variables
    private Container container;
    private JLabel Tittle;
    private JButton nextBtn;
    private Cursor cursor;
    private ImageIcon img;
    BufferedImage bufferedImage;

    // Font
    Font fontOne = new Font("Arial",Font.BOLD,45);
    Font fontTwo = new Font("Thoma",Font.PLAIN,30);
    Font fontThree = new Font("cambria",Font.PLAIN,20);

    public homePage() {

        mainFrame();

        container = this.getContentPane();
        container.setBackground(Color.GRAY);
        container.setLayout(null);

        // TITTLE SECTION

        Tittle = new JLabel();
        Tittle.setText("Welcome to Sonar Bank!");
        Tittle.setBounds(100, 140, 550, 50);
        Tittle.setFont(fontOne);
        Tittle.setForeground(Color.BLACK);
        container.add(Tittle);


        // BUTTON SECTION
//        img = new ImageIcon(getClass().getResource("/Images/next_arrow_rs.png"));
        nextBtn = new JButton("Next");
        nextBtn.setFont(fontTwo);
        nextBtn.setBounds(280,250,120,70);
        nextBtn.setCursor(cursor);
        container.add(nextBtn);

        nextBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                Login userlogin = new Login();
                userlogin.setVisible(true);
            }
        });


//        try {
//            bufferedImage = ImageIO.read(new File("/images/next_arrow.png"));
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//
//        Image image = bufferedImage.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
//
//        nextBtn = new JLabel(img);
//        nextBtn.setBounds(10, 10, img.getIconWidth(), img.getIconHeight());
//        container.add(nextBtn);
//        nextBtn.setCursor(cursor);


    }

    public void mainFrame()
    {
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //setSize(600,500);
        setBounds(500,300,700,500);
        setTitle("Home Page");
    }

    public static void main(String[] args) {
        homePage frame = new homePage();
        frame.setVisible(true);
    }
}
